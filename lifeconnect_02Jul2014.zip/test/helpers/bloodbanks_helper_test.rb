require 'test_helper'

class BloodbanksHelperTest < ActionView::TestCase
end
