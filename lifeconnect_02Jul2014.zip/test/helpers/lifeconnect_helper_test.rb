require 'test_helper'

class LifeconnectHelperTest < ActionView::TestCase
end
