require 'test_helper'

class BloodbankstocksHelperTest < ActionView::TestCase
end
