require 'test_helper'

class BloodstockHelperTest < ActionView::TestCase
end
