require 'test_helper'

class BloodbankstockHelperTest < ActionView::TestCase
end
