require 'test_helper'

class BloodstocksHelperTest < ActionView::TestCase
end
