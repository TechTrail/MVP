require 'test_helper'

class BloodbankstockTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
