require 'test_helper'

class BloodstockTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
