require 'test_helper'

class BloodbankTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
