class Bloodbank < ActiveRecord::Base
has_many :bloodstocks
end
