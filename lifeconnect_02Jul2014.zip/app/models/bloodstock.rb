class Bloodstock < ActiveRecord::Base
belongs_to :bloodbank
end
